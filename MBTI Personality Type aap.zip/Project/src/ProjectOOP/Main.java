package ProjectOOP;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.List;


class PersonalityQuestion {
    private final String text;
    public PersonalityQuestion(String text) {
        this.text = text;
    }
    public String getText() {
        return text;
    }
}


class PersonalityTest {
    private final String[] answers = {"Yes", "Most times", "Sometimes", "No"};
    private final double[] scores = {2, 1.5, 1, 0};
    private final List<PersonalityQuestion> questions = new ArrayList<>();
    private int currentIndex = 0;
    private double totalScore = 0;

    public PersonalityTest() {
        addQuestions();
    }

    private void addQuestions() {
        questions.add(new PersonalityQuestion("Do you enjoy being around people?"));
        questions.add(new PersonalityQuestion("Do you like planning everything in advance?"));
        questions.add(new PersonalityQuestion("Do you often trust your feelings over logic?"));
        questions.add(new PersonalityQuestion("Do you find it easy to make decisions quickly?"));
        questions.add(new PersonalityQuestion("Do you enjoy trying new things or experiences?"));
        questions.add(new PersonalityQuestion("Do you often try to avoid conflicts with others?"));
        questions.add(new PersonalityQuestion("Do you get stressed or anxious easily?"));
        questions.add(new PersonalityQuestion("Do you keep your space organized most of the time?"));
        questions.add(new PersonalityQuestion("Do you like to spend time alone to recharge?"));
        questions.add(new PersonalityQuestion("Do you prefer detailed planning over spontaneity?"));
        questions.add(new PersonalityQuestion("Do you follow your heart more than your head?"));
        questions.add(new PersonalityQuestion("Do you often find yourself lost in thoughts and imagination?"));
        questions.add(new PersonalityQuestion("Do you prefer meaningful one-on-one conversations over group chats?"));
        questions.add(new PersonalityQuestion("Do you enjoy taking time to reflect before speaking?"));
    }

    public String[] getAnswers() {
        return answers;
    }

    public PersonalityQuestion getCurrentQuestion() {
        return questions.get(currentIndex);
    }

    public void addScore(int selectedIndex) {
        totalScore += scores[selectedIndex];
    }

    public boolean hasNext() {
        return currentIndex < questions.size() - 1;
    }

    public void nextQuestion() {
        currentIndex++;
    }

    public double getTotalScore() {
        return totalScore;
    }

    public String interpretResult() {
        if (totalScore >= 26) {
            return "💖 Radiant Extrovert (MBTI: ENFJ)\nYou thrive in social settings, love being the center of attention, and inspire those around you with your infectious energy. You are confident, bold, and embrace new experiences with open arms.\n\n*MBTI Dimensions:*\nE - Extraversion\nN - Intuition\nF - Feeling\nJ - Judging";
        } else if (totalScore >= 22) {
            return "🎉 Charismatic Connector (MBTI: ESFP)\nYou are socially dynamic and emotionally intelligent. Your charm and enthusiasm allow you to build deep connections quickly, and you uplift those around you.\n\n*MBTI Dimensions:*\nE - Extraversion\nS - Sensing\nF - Feeling\nP - Perceiving";
        } else if (totalScore >= 18) {
            return "🔄 Ambivert Balance (MBTI: INFP)\nYou are both introspective and outgoing. You know when to engage and when to step back, making you emotionally balanced and adaptable in various social contexts.\n\n*MBTI Dimensions:*\nI - Introversion\nN - Intuition\nF - Feeling\nP - Perceiving";
        } else if (totalScore >= 14) {
            return "🧠 Thoughtful Introvert (MBTI: ISTJ)\nYou appreciate solitude, deep thinking, and meaningful interactions. You're highly introspective, sensitive to your surroundings, and often find creativity in quiet spaces.\n\n*MBTI Dimensions:*\nI - Introversion\nS - Sensing\nT - Thinking\nJ - Judging";
        } else if (totalScore >= 10) {
            return "🎨 Quiet Creative (MBTI: INTP)\nYou’re reflective, observant, and imaginative. You often express your thoughts through art, writing, or innovation. You find beauty in silence and meaning in the unseen.\n\n*MBTI Dimensions:*\nI - Introversion\nN - Intuition\nT - Thinking\nP - Perceiving";
        } else {
            return "🧩 Enigmatic Soul (MBTI: INFJ)\nYou're a unique blend of mystery and depth. You may not fit into typical categories, but your individuality makes you incredibly special. People are often drawn to your quiet wisdom and aura of calm.\n\n*MBTI Dimensions:*\nI - Introversion\nN - Intuition\nF - Feeling\nJ - Judging";
        }
    }

    public void reset() {
        currentIndex = 0;
        totalScore = 0;
    }
}


public class Main extends Application {

    private PersonalityTest test = new PersonalityTest();

    private final String peach = "#FFDAB9";           // Peach
    private final String lightPeach = "#FFF0E6";      // Light peach
    private final String lightPurple = "#D8B4FE";     // Light purple
    private final String mediumPurple = "#9F7AEA";    // Medium purple
    private final String darkPurple = "#6B46C1";      // Darker purple
    private final String accentPurple = "#5A189A";    // Accent purple (original dark purple you had)
    private final String softPink = "#FFE4E1";        // Soft pink for backgrounds
    private final String backgroundGradient = "linear-gradient(to bottom right, #FFF0E6, #D8B4FE)";

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("✨ Personality Quiz ✨");

        // Home Scene
        Label welcomeLabel = new Label("✨ Welcome to the Personality Quiz ✨");
        welcomeLabel.setFont(Font.font("Poppins", 30));
        welcomeLabel.setTextFill(Color.web(darkPurple));

        Button startButton = new Button("Take Test");
        startButton.setFont(Font.font("Poppins", 18));
        startButton.setTextFill(Color.web(peach));
        startButton.setStyle("-fx-background-radius: 25; -fx-background-color: linear-gradient(to right, " + mediumPurple + ", " + darkPurple + "); -fx-padding: 10 30;");
        startButton.setOnMouseEntered(e -> startButton.setStyle("-fx-background-radius: 25; -fx-background-color: linear-gradient(to right, " + lightPurple + ", " + mediumPurple + "); -fx-padding: 10 30;"));
        startButton.setOnMouseExited(e -> startButton.setStyle("-fx-background-radius: 25; -fx-background-color: linear-gradient(to right, " + mediumPurple + ", " + darkPurple + "); -fx-padding: 10 30;"));

        Button exitButton = new Button("Exit");
        exitButton.setFont(Font.font("Poppins", 18));
        exitButton.setTextFill(Color.web(peach));
        exitButton.setStyle("-fx-background-radius: 25; -fx-background-color: #E07A5F; -fx-padding: 10 30;"); 
        exitButton.setOnMouseEntered(e -> exitButton.setStyle("-fx-background-radius: 25; -fx-background-color: #F4A261; -fx-padding: 10 30;"));
        exitButton.setOnMouseExited(e -> exitButton.setStyle("-fx-background-radius: 25; -fx-background-color: #E07A5F; -fx-padding: 10 30;"));
        exitButton.setOnAction(e -> primaryStage.close());

        VBox homeLayout = new VBox(30, welcomeLabel, startButton, exitButton);
        homeLayout.setAlignment(Pos.CENTER);
        homeLayout.setPadding(new Insets(40));
        homeLayout.setStyle("-fx-background-color: " + backgroundGradient + ";");
        Scene homeScene = new Scene(homeLayout, 720, 620);

        // Quiz Scene Components
        Label title = new Label("✨ Discover Your Personality Type ✨");
        title.setFont(Font.font("Poppins", 32));
        title.setTextFill(Color.web(darkPurple));

        Label questionLabel = new Label(test.getCurrentQuestion().getText());
        questionLabel.setFont(Font.font("Segoe UI", 20));
        questionLabel.setWrapText(true);
        questionLabel.setTextFill(Color.web(mediumPurple));
        questionLabel.setPadding(new Insets(10));

        ToggleGroup group = new ToggleGroup();
        RadioButton[] options = new RadioButton[test.getAnswers().length];
        for (int i = 0; i < test.getAnswers().length; i++) {
            options[i] = new RadioButton(test.getAnswers()[i]);
            options[i].setToggleGroup(group);
            options[i].setFont(Font.font("Segoe UI", 16));
            options[i].setTextFill(Color.web(darkPurple));
            options[i].setPadding(new Insets(10, 0, 10, 15));
            options[i].setStyle("-fx-background-color: " + lightPeach + "; -fx-background-radius: 10;");
            int finalI = i;
            options[i].setOnMouseEntered(e -> options[finalI].setStyle("-fx-background-color: " + peach + "; -fx-border-radius: 10; -fx-border-color: " + mediumPurple + ";"));
            options[i].setOnMouseExited(e -> options[finalI].setStyle("-fx-background-color: " + lightPeach + "; -fx-background-radius: 10;"));
        }

        Button nextButton = new Button("Next ➡");
        nextButton.setFont(Font.font("Poppins", 18));
        nextButton.setTextFill(Color.web(peach));
        nextButton.setStyle("-fx-background-radius: 25; -fx-background-color: linear-gradient(to right, " + mediumPurple + ", " + darkPurple + "); -fx-padding: 12 30;");
        nextButton.setEffect(new DropShadow());
        nextButton.setOnMouseEntered(e -> nextButton.setStyle("-fx-background-radius: 25; -fx-background-color: linear-gradient(to right, " + lightPurple + ", " + mediumPurple + "); -fx-padding: 12 30;"));
        nextButton.setOnMouseExited(e -> nextButton.setStyle("-fx-background-radius: 25; -fx-background-color: linear-gradient(to right, " + mediumPurple + ", " + darkPurple + "); -fx-padding: 12 30;"));

        Label resultLabel = new Label();
        resultLabel.setFont(Font.font("Poppins", 18));
        resultLabel.setTextFill(Color.web(darkPurple));
        resultLabel.setWrapText(true);
        resultLabel.setVisible(false);
        resultLabel.setPadding(new Insets(20, 10, 10, 10));
        resultLabel.setStyle("-fx-background-color: " + softPink + "; -fx-background-radius: 15;");

        Button restartButton = new Button("🔁 Restart");
        restartButton.setFont(Font.font("Poppins", 16));
        restartButton.setVisible(false);
        restartButton.setTextFill(Color.web(peach));
        restartButton.setStyle("-fx-background-radius: 25; -fx-background-color: linear-gradient(to right, " + mediumPurple + ", " + darkPurple + "); -fx-padding: 10 20;");
        restartButton.setOnMouseEntered(e -> restartButton.setStyle("-fx-background-radius: 25; -fx-background-color: linear-gradient(to right, " + lightPurple + ", " + mediumPurple + "); -fx-padding: 10 20;"));
        restartButton.setOnMouseExited(e -> restartButton.setStyle("-fx-background-radius: 25; -fx-background-color: linear-gradient(to right, " + mediumPurple + ", " + darkPurple + "); -fx-padding: 10 20;"));

        VBox optionsBox = new VBox(10);
        optionsBox.getChildren().addAll(options);
        optionsBox.setPadding(new Insets(10));
        optionsBox.setStyle("-fx-background-color: " + lightPeach + "; -fx-background-radius: 20;");
        optionsBox.setAlignment(Pos.CENTER_LEFT);

        VBox quizLayout = new VBox(15, title, questionLabel, optionsBox, nextButton, resultLabel, restartButton);
        quizLayout.setPadding(new Insets(40));
        quizLayout.setAlignment(Pos.TOP_CENTER);
        quizLayout.setStyle("-fx-background-color: " + backgroundGradient + ";");

        Scene quizScene = new Scene(quizLayout, 720, 620);

        // Event Handlers
        startButton.setOnAction(e -> {
            test.reset();
            updateQuestion(questionLabel, options);
            group.selectToggle(null);
            resultLabel.setVisible(false);
            restartButton.setVisible(false);
            nextButton.setVisible(true);
            primaryStage.setScene(quizScene);
        });

        nextButton.setOnAction(e -> {
            RadioButton selected = (RadioButton) group.getSelectedToggle();
            if (selected == null) {
                Alert alert = new Alert(Alert.AlertType.WARNING, "Please select an answer before proceeding.");
                alert.setHeaderText(null);
                alert.showAndWait();
                return;
            }
            int selectedIndex = -1;
            for (int i = 0; i < options.length; i++) {
                if (options[i] == selected) {
                    selectedIndex = i;
                    break;
                }
            }
            test.addScore(selectedIndex);

            if (test.hasNext()) {
                test.nextQuestion();
                updateQuestion(questionLabel, options);
                group.selectToggle(null);
            } else {
                // Show result
                questionLabel.setVisible(false);
                optionsBox.setVisible(false);
                nextButton.setVisible(false);
                resultLabel.setText(test.interpretResult());
                resultLabel.setVisible(true);
                restartButton.setVisible(true);
            }
        });

        restartButton.setOnAction(e -> {
            test.reset();
            questionLabel.setVisible(true);
            optionsBox.setVisible(true);
            nextButton.setVisible(true);
            resultLabel.setVisible(false);
            restartButton.setVisible(false);
            updateQuestion(questionLabel, options);
            group.selectToggle(null);
        });

        primaryStage.setScene(homeScene);
        primaryStage.show();
    }

    private void updateQuestion(Label questionLabel, RadioButton[] options) {
        PersonalityQuestion current = test.getCurrentQuestion();
        questionLabel.setText(current.getText());
        String[] answers = test.getAnswers();
        for (int i = 0; i < options.length; i++) {
            options[i].setText(answers[i]);
            options[i].setSelected(false);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
